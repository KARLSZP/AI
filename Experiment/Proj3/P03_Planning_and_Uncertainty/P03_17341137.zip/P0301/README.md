# README

Since Errors occurred millions of times on pddl on-line editor, I turn to local ff-planer for help.

![image-20191111194420203](.assets/image-20191111194420203.png)

---

Please do as follow for you check:

1. `cd [Prob*]`
2. `ff -o domain_cube.pddl -f cube_prob*.pddl`

Then u will see:

**Prob 1**

![](./Prob1/res1.png)


**Prob 2**

![](./Prob2/res2.png)

**Prob 3**

![](./Prob3/res3.png)

**Prob 4**

![](./Prob4/res4.png)

---

Thanks XD. 2019/10